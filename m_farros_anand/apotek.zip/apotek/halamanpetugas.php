<html>
    <head>
        <title>halamanpetugas</title>
        <link rel="stylesheet" type="text/css" href="halamanpetugas.css">
    </head>
    <body>
        <div class="form-box">
            <ul>
                <h1 align="center">Apotek GWS</h1>
                <li><a href="halamanpetugas.php">Home</a></li>
                <li><a href="insert.php">Obat</a></li>
                <li><a href="rak.php">Rak</a></li>
                <li><a href="transaksi.php">Transaksi</a></li>
                <li><a href="login.php">Logout</a></li>
            </ul>
        </div>
        <h2 align="center">Home</h2>
        
        
    </body>
</html>