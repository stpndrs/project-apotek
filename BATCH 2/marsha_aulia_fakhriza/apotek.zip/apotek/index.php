<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OBAT</title>
  </head>
  <body>
  <div>
      <a href="insert.php">Tambah Data Obat</a>
    </div>
    <table border="1" width="50%" align="center">
      <thead>
        <tr>
          <th>No</th>
          <th>Judul</th>
          <th>Tanggal</th>
          <th>Gambar</th>
          <th>Operation</th>
        </tr>
      </thead>
      <tbody>
      <?php
    include 'config.php';
    $query = mysqli_query($connect, "SELECT * FROM tb_berita");
    while($data = mysqli_fetch_array($query)) {
    ?>
    <tr>
  <td><?= $data['id_berita'] ?></td>
  <td><?= $data['judul'] ?></td>
  <td><?= $data['tanggal'] ?></td>
  <td><img src="uploads/<?php echo $data['gambar']?>" width="100"alt=""></td>
  <td>
    <a href="delete.php?id=<?php echo $data['id_berita'] ?>">delete</a>
    <a href="update.php?id=<?php echo $data['id_berita'] ?>">update</a>
  </td>
    </tr>
    <?php
    }
    ?>
      </tbody>
    </table>
    </td>
  </body>
</html>