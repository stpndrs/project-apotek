<html>
    <head>
        <title>Logout</title>
        <link rel="stylesheet" href="login.php">
    </head>
    <body>
        
    </body>
</html>