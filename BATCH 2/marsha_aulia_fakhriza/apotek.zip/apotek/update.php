<?php
include 'config.php';
if (isset($_POST['submit']))  {
    $judul = $_POST['judul'];
    $isi = $_POST['isi'];
    $tanggal = $_POST['tanggal'];
    $gambar = $_POST['gambar'];
    $penulis = $_POST['penulis'];
    $id_kategori = $_POST['id_kategori'];
    $idUpdate = $_POST['id'];

    $queryUpdate = mysqli_query($connect, "UPDATE tb_berita SET judul='$judul', isi='$isi', tanggal='$tanggal', gambar='$gambar', penulis='$penulis', id_kategori='$id_kategori' WHERE id_berita=$idUpdate");

    header('location: index1.php');

}
?>
<html>
    <head>
        <title>Form Ubah siswa</title>
    </head>
    <body>
        <h1>Ubah Siswa</h1>
        <?php
        $id = $_GET['id'];
        $query = mysqli_query($connect, "SELECT * FROM tb_berita WHERE id_berita = $id");
        $data = mysqli_fetch_array($query);
        ?>
        <form method="post">
            <table>
            <tr>
                <td>Judul</td>
                <td><input type="text" name="judul" id="judul" value="<?php echo $data['judul'] ?>"></td>
            </tr>
            <tr>
                <td>Isi</td>
                <td><input type="text" name="isi" id="isi" value="<?php echo $data['isi'] ?>"></td>
            </tr>
            <tr>
                <td>Tanggal</td>
                <td><input type="date" name="tanggal" id="tanggal" value="<?php echo $data['tanggal'] ?>"></td>
            </tr>
            <tr>
                <td>Gambar</td>
                <td><input type="file" name="gambar" id="gambar" value="<?php echo $data['gambar'] ?>"></td>
            </tr>
            <tr>
                <td></td>
                <td><img src="uploads/<?php echo $data['gambar'] ?>" width="200" alt=""></td>
            </tr>
            <tr>
                <td>Penulis</td>
                <td><input type="text" name="penulis" id="penulis" value="<?php echo $data['penulis'] ?>"></td>
            </tr>
            <tr>
                <td>Kategori</td>
                <td><select name="id_kategori" >
                    <?php
                    $queryKategori = mysqli_query($connect, "SELECT * FROM kategori");
                    while ($dataKategori = mysqli_fetch_array($queryKategori)) {
                    $selected = null;
                    if ($data['id_kategori'] == $dataKategori['Id_kategori']) {
                        $selected = 'selected';
                    }
                    ?>
                    <option value="<?php echo $dataKategori['id_kategori'] ?>"<?php echo $selected ?>><?php echo $dataKategori['nama_kategori'] ?></option>
                    <?php
                    }
                    ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td><input type="hidden" name="id" value="<?php echo $data['id_berita'] ?>"></td>
                <td><button type="submit" name="submit" value="update">Ubah</button></td>
            </tr>
                </table>
        </form>
    </body>
</html>